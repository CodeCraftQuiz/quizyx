const mongoose = require('mongoose');

const questionSchema = new mongoose.Schema({
  topic: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Topic',
    required: true
  },
  text: {
    type: String,
    required: true,
    trim: true
  },
  answers: [{
    text: { type: String, required: true, trim: true },
    isCorrect: { type: Boolean, default: false }
  }]
}, { timestamps: true });

// Walidacja: dokładnie jedna odpowiedź musi być poprawna
questionSchema.pre('save', function(next) {
  const correctCount = this.answers.filter(a => a.isCorrect).length;
  if (correctCount !== 1) {
    return next(new Error('Pytanie musi mieć dokładnie jedną poprawną odpowiedź!'));
  }
  next();
});

module.exports = mongoose.model('Question', questionSchema);