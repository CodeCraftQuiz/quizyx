const express = require('express');
const router = express.Router();
const Topic = require('../models/Topic');

// GET wszystkie tematy
router.get('/', async (req, res) => {
  try {
    const topics = await Topic.find().sort({ createdAt: -1 });
    res.json(topics);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST dodaj temat
router.post('/', async (req, res) => {
  try {
    const { name } = req.body;
    if (!name || typeof name !== 'string') {
      return res.status(400).json({ message: 'Nazwa tematu jest wymagana (tekst).' });
    }

    const topic = new Topic({ name: name.trim() });
    const saved = await topic.save();
    res.status(201).json(saved);
  } catch (err) {
    if (err.code === 11000) {
      res.status(400).json({ message: 'Temat o tej nazwie już istnieje.' });
    } else {
      res.status(400).json({ message: err.message });
    }
  }
});

module.exports = router;