const express = require('express');
const router = express.Router();
const Question = require('../models/Question');
const Topic = require('../models/Topic');

// GET wszystkie pytania (z tematami)
router.get('/', async (req, res) => {
  try {
    const questions = await Question.find().populate('topic', 'name').sort({ createdAt: -1 });
    res.json(questions);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET pytania dla danego tematu
router.get('/topic/:topicId', async (req, res) => {
  try {
    const questions = await Question.find({ topic: req.params.topicId })
      .populate('topic', 'name');
    res.json(questions);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST dodaj pytanie
router.post('/', async (req, res) => {
  try {
    const { topicId, text, answers } = req.body;

    // Walidacja
    if (!topicId || !text || !Array.isArray(answers) || answers.length < 2) {
      return res.status(400).json({ message: 'Wszystkie pola są wymagane. Odpowiedzi muszą być tablicą z min. 2 elementami.' });
    }

    // Sprawdź, czy temat istnieje
    const topic = await Topic.findById(topicId);
    if (!topic) {
      return res.status(404).json({ message: 'Temat nie istnieje.' });
    }

    // Upewnij się, że dokładnie jedna odpowiedź jest poprawna
    const correctCount = answers.filter(a => a.isCorrect).length;
    if (correctCount !== 1) {
      return res.status(400).json({ message: 'Dokładnie jedna odpowiedź musi być poprawna.' });
    }

    const question = new Question({ topic: topicId, text, answers });
    const saved = await question.save();

    // Zwróć z pełnym tematem
    await saved.populate('topic', 'name');
    res.status(201).json(saved);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

module.exports = router;